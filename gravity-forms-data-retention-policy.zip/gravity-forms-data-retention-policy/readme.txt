=== Gravity Forms Data Retention Policy ===
Contributors:
Tags: gravity forms, data retention, privacy, gdpr, multisite
Requires at least: 7.0
Tested up to: 7.0
Stable tag: 1.2.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Enforces a site-wide maximum entry retention policy for every Gravity Forms form.

== Description ==

Gravity Forms Data Retention Policy adds a Retention Policy tab to the main Gravity Forms settings screen. The setting is local to each WordPress site, including each site in a multisite network.

The default configuration permanently deletes entries after 28 days, but installing or activating the WordPress plugin does not change forms. Administrators save the configuration, run a read-only impact test, review only the forms that would change, then explicitly activate the tested policy. Impact rows include inherited forms that exactly match the active policy and would follow a looser default, plus form status, current policy, saved-entry counts, affected-entry date range, and File Upload or Post Image counts. Every affected form is selected by default; unchecked forms remain unchanged and are stored as exceptions to ongoing enforcement. The report notes that Save and Continue drafts are also subject to Gravity Forms retention but are not included in the saved-entry total.

When a tested policy is activated, forms matching the previously applied policy follow the new setting. A form with a custom policy remains independent unless its policy is looser than the new site ceiling. Gravity Forms performs the scheduled cleanup through its native daily retention task.

The settings page can also scan active forms for references in published and draft site content, post metadata, common widgets, theme settings, and active theme files. Content locations are labelled Published or Draft; all other content statuses are ignored. The results show every active form and its detected usage locations. Forms with no detected usage are selected by default for a separate deactivation step, which performs another server-side scan before making changes. Dynamic plugin code and external applications cannot be conclusively detected.

== Installation ==

1. Install and activate Gravity Forms 2.5.8 or later.
2. Upload the plugin ZIP through Plugins > Add New > Upload Plugin.
3. Activate the plugin for one site or network activate it on multisite.
4. Open Forms > Settings > Retention Policy on each site, save the configuration, run Test Policy, review the report, and activate the tested policy.

== Frequently Asked Questions ==

= Does each multisite site have its own policy? =

Yes. Settings use normal site options, so each site's Forms > Settings > Retention Policy tab is independent.

= Can a form use a stricter rule? =

Yes. A form may permanently delete entries sooner, but it cannot exceed the site's day limit or use a weaker disposal action.

= Does this plugin run its own deletion job? =

No. It configures and enforces Gravity Forms' native personal-data retention fields. Gravity Forms performs cleanup through its daily scheduled task.

== Changelog ==

= 1.2.7 =
* Migrate update discovery to AS Update Controller. Preserve feature settings and plugin identity.
* Match WordPress 7.0 / PHP 7.4 requirements.


= 1.2.6 =

* Matched the activation control to the visible secondary action style and added an inline contrast fallback.

= 1.2.5 =

* Always displayed affected-entry dates as an explicit oldest-to-youngest range.

= 1.2.4 =

* Added form status and affected-entry date ranges to the policy impact table.
* Removed the redundant Proposed column and explicitly retained inherited forms during policy loosening.
* Fixed primary activation button contrast.

= 1.2.3 =

* Limited content usage detection to published and draft items and displayed their status in scan results.

= 1.2.2 =

* Simplified the policy controls and made test and scan reports page-session-only.

= 1.2.1 =

* Fixed secondary action button contrast in the Gravity Forms settings interface.

= 1.2.0 =

* Enforced test-before-activation with selectable per-form policy changes.
* Added persistent exceptions for unchecked forms.
* Expanded the usage report to all active forms and their detected locations.
* Added scan-gated, selectable deactivation for forms with no detected usage.

= 1.1.0 =

* Removed automatic form changes during plugin activation.
* Added read-only policy testing, explicit activation, and active/inactive status.
* Added entry and file-upload impact reporting.
* Added conservative unused-form scanning and deactivation.

= 1.0.1 =

* Changed inherited forms to follow site policy changes.
* Preserved custom form policies unless they exceed the new site ceiling.

= 1.0.0 =

* Added site-wide retention settings and defaults.
* Added enforcement for existing, new, imported, and updated forms.
* Added single-site and multisite support.
* Added WordPress-native GitHub release updates.
